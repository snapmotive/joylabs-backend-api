/**
 * Self-contained catalog API handler with axios embedded
 * This file can be deployed directly to Lambda without external dependencies
 */

// Simplified axios-like HTTP client using Node.js https module
const http = require('http');
const https = require('https');
const { URL } = require('url');
const { StringDecoder } = require('string_decoder');

// Helper to log detailed info
const log = (msg, obj = {}) => {
  console.log(`${msg}`, JSON.stringify(obj));
};

// Handle CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Content-Type': 'application/json'
};

// Response helper
const response = (statusCode, body) => ({
  statusCode,
  headers: corsHeaders,
  body: JSON.stringify(body)
});

// Simple HTTP client
const request = async (options) => {
  return new Promise((resolve, reject) => {
    const url = new URL(options.url);
    const protocol = url.protocol === 'https:' ? https : http;
    
    // Append query parameters if provided
    if (options.params) {
      Object.entries(options.params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, value);
        }
      });
    }
    
    const requestOptions = {
      method: options.method || 'GET',
      hostname: url.hostname,
      path: url.pathname + url.search,
      headers: {
        ...options.headers,
      }
    };
    
    const req = protocol.request(requestOptions, (res) => {
      const responseBody = [];
      const decoder = new StringDecoder('utf-8');
      
      res.on('data', (chunk) => {
        responseBody.push(decoder.write(chunk));
      });
      
      res.on('end', () => {
        responseBody.push(decoder.end());
        const body = responseBody.join('');
        
        let data;
        try {
          data = body ? JSON.parse(body) : {};
        } catch (e) {
          data = body;
        }
        
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({
            status: res.statusCode,
            data,
            headers: res.headers
          });
        } else {
          reject({
            response: {
              status: res.statusCode,
              data,
              headers: res.headers
            },
            message: `Request failed with status code ${res.statusCode}`
          });
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    if (options.data) {
      req.write(JSON.stringify(options.data));
    }
    
    req.end();
  });
};

// Simplified API client
const api = {
  get: (url, config = {}) => request({ url, method: 'GET', ...config }),
  post: (url, data, config = {}) => request({ url, method: 'POST', data, ...config })
};

// Handler for Square API auth
const verifyToken = async (token) => {
  try {
    log('Verifying Square token:', { tokenPrefix: token.substring(0, 5) });
    
    // Call Square API directly to validate token
    const meResponse = await api.get('https://connect.squareup.com/v2/merchants/me', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    if (meResponse.status === 200 && meResponse.data?.merchant?.id) {
      log('Token verified successfully', { 
        merchantId: meResponse.data.merchant.id,
        businessName: meResponse.data.merchant.business_name || 'Unknown'
      });
      return {
        isValid: true,
        merchantId: meResponse.data.merchant.id,
        businessName: meResponse.data.merchant.business_name || 'Unknown'
      };
    }
    
    log('Token verification failed - invalid response', { status: meResponse.status });
    return { isValid: false };
  } catch (error) {
    log('Token verification error', { 
      status: error.response?.status,
      message: error.message,
      data: error.response?.data
    });
    return { isValid: false, error };
  }
};

// List catalog items
const listCatalogItems = async (token, queryStringParams = {}) => {
  try {
    const { types = 'ITEM', limit = 100, cursor } = queryStringParams;
    
    log('Listing catalog items', { types, limit, cursor });
    
    const url = `https://connect.squareup.com/v2/catalog/list`;
    const params = { types };
    if (cursor) params.cursor = cursor;
    if (limit) params.limit = limit;
    
    // Call Square API directly
    const listResponse = await api.get(url, {
      params,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    log('Catalog list response', { 
      status: listResponse.status,
      objectCount: listResponse.data.objects?.length
    });
    
    return response(200, {
      success: true,
      objects: listResponse.data.objects || [],
      cursor: listResponse.data.cursor
    });
  } catch (error) {
    log('Error listing catalog items', { 
      status: error.response?.status,
      message: error.message,
      data: error.response?.data
    });
    
    return response(error.response?.status || 500, {
      success: false,
      error: error.response?.data?.errors?.[0]?.detail || error.message,
      code: error.response?.data?.errors?.[0]?.code || 'unknown_error'
    });
  }
};

// Search catalog
const searchCatalogItems = async (token, requestBody) => {
  try {
    log('Searching catalog items', { 
      objectTypes: requestBody.object_types,
      query: requestBody.query
    });
    
    const url = `https://connect.squareup.com/v2/catalog/search`;
    
    // Call Square API directly
    const searchResponse = await api.post(url, requestBody, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    log('Catalog search response', { 
      status: searchResponse.status,
      objectCount: searchResponse.data.objects?.length
    });
    
    return response(200, {
      success: true,
      objects: searchResponse.data.objects || [],
      cursor: searchResponse.data.cursor,
      matchedVariationIds: searchResponse.data.matched_variation_ids || []
    });
  } catch (error) {
    log('Error searching catalog items', { 
      status: error.response?.status,
      message: error.message,
      data: error.response?.data
    });
    
    return response(error.response?.status || 500, {
      success: false,
      error: error.response?.data?.errors?.[0]?.detail || error.message,
      code: error.response?.data?.errors?.[0]?.code || 'unknown_error'
    });
  }
};

// Main handler function
exports.handler = async (event) => {
  log('Received event', { 
    path: event.path,
    method: event.httpMethod,
    queryParams: event.queryStringParameters
  });
  
  // Handle OPTIONS for CORS
  if (event.httpMethod === 'OPTIONS') {
    return response(200, { message: 'CORS preflight response' });
  }
  
  // Verify authorization
  const authHeader = event.headers?.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    log('Missing or invalid authorization header');
    return response(401, { error: 'Missing or invalid authorization header' });
  }
  
  const token = authHeader.split(' ')[1];
  const tokenVerification = await verifyToken(token);
  
  if (!tokenVerification.isValid) {
    log('Token validation failed');
    return response(401, { 
      error: 'Invalid access token',
      details: tokenVerification.error?.response?.data?.errors
    });
  }
  
  try {
    // Route the request to the appropriate handler
    if (event.path === '/v2/catalog/list' && event.httpMethod === 'GET') {
      return await listCatalogItems(token, event.queryStringParameters);
    } 
    else if (event.path === '/v2/catalog/search' && event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      return await searchCatalogItems(token, body);
    }
    else if (event.path === '/api/catalog/list' && event.httpMethod === 'GET') {
      // Legacy path support
      return await listCatalogItems(token, event.queryStringParameters);
    }
    else if (event.path === '/api/catalog/search' && event.httpMethod === 'POST') {
      // Legacy path support
      const body = JSON.parse(event.body || '{}');
      return await searchCatalogItems(token, body);
    }
    else {
      log('Unsupported route', { path: event.path, method: event.httpMethod });
      return response(404, { 
        error: 'Not Found', 
        path: event.path, 
        method: event.httpMethod 
      });
    }
  } catch (error) {
    log('Unhandled error', { message: error.message, stack: error.stack });
    return response(500, { 
      error: 'An unexpected error occurred',
      message: error.message
    });
  }
}; 